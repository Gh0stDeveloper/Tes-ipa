# S4NTOS INJECTOR — paquete de personalización de iOS

## Cambios aplicados en el IPA generado
- `CFBundleDisplayName` y `CFBundleName` = **S4NTOS INJECTOR**.
- Iconos PNG iPhone/iPad generados desde la imagen proporcionada, sin rediseñarla.
- Imágenes de splash PNG (1x, 2x, 3x), con los valores `UILaunchScreen/UIImageName` y `UIColorName` configurados en Info.plist.
- Mensajes y pantallas de bienvenida, «Acerca de» y créditos de bienvenida editados en inglés, chino y vietnamita. La clave `onboarding.welcome_message` queda como **Developer by S4NTOS INJECTOR**.
- Identificador del paquete, ejecutable Mach-O, formatos técnicos, recursos internos y funciones originales conservados.

## Importante: compilación del catálogo y firma

El IPA `S4NTOS_INJECTOR_unsigned.ipa` es una variante de recursos **sin firmar**. Las imágenes PNG nuevas están dentro del bundle, y se ha cambiado la referencia a iconos PNG para evitar el icono anterior. Pero **el `Assets.car` original sigue compilado con el icono antiguo**: la carga del splash y del icono en todos los iOS **NO está verificada** con este IPA intermedio.

Para garantizar que iOS cargue el nuevo icono/splash desde el catálogo:

1. En macOS con Xcode instalado, sitúa este directorio de recursos junto al IPA generado.
2. Ejecuta `bash scripts/compile_assets_macos.sh ../S4NTOS_INJECTOR_unsigned.ipa ../S4NTOS_INJECTOR_compiled_unsigned.ipa` desde este directorio.
3. El script compila el catálogo nuevo y sustituye `Assets.car` (se comprobó que el original contiene únicamente `AppIcon`).
4. Firma posteriormente la aplicación con un certificado y perfil de aprovisionamiento válidos para el método de instalación deseado. Hay que verificar los entitlements y dependencias de la app original.
5. Instala y prueba en un dispositivo compatible; no hay pruebas de ejecución disponibles en este entorno.

**Advertencia de compatibilidad:** la app original contiene la indicación de que exige firma empresarial, además de un bundle ID `com.apple.mobile.MobileHouseArrest`. Un cambio de firma puede afectar sus prestaciones; **no se garantiza la ejecución** en iOS tras firmar. No se ha alterado su ejecutable ni se han neutralizado comprobaciones de seguridad.

## Archivos
- `Assets.xcassets/` contiene iconos y splash compilables con Xcode.
- `scripts/compile_assets_macos.sh` compila el catálogo e integra el IPA sin reescribir el ejecutable.
- `manifest.json` resume cambios auditables.

## GitHub Actions sin Mac propio

Hay un workflow listo para GitHub Actions en `.github/workflows/compile-ipa.yml`. En un **repositorio privado** incluye los archivos de esta carpeta en la raíz y copia también `S4NTOS_INJECTOR_unsigned.ipa` a la raíz. Desde la pestaña **Actions**, ejecuta «S4NTOS INJECTOR — Compile iOS branding» mediante **Run workflow**. Descarga el artefacto final (`S4NTOS_INJECTOR_compiled_unsigned.ipa`) y **fírmalo** antes de instalarlo. Este workflow no necesita credenciales porque NO firma ni instala el IPA.
