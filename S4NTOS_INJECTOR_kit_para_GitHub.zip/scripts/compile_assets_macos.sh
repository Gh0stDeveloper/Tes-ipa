#!/usr/bin/env bash
# Compile the provided icon and launch image into Assets.car using Xcode's actool.
set -euo pipefail
if ! command -v xcrun >/dev/null; then
  echo "Error: this step requires macOS and Xcode (xcrun actool)." >&2; exit 1
fi
HERE="$(cd "$(dirname "$0")" && pwd)"
INPUT_IPA="${1:-$HERE/../S4NTOS_INJECTOR_unsigned.ipa}"
OUTPUT_IPA="${2:-$HERE/../S4NTOS_INJECTOR_compiled_unsigned.ipa}"
if [[ ! -f "$INPUT_IPA" ]]; then echo "No IPA: $INPUT_IPA" >&2; exit 1; fi
# Resolve relative paths before changing workdirs.
INPUT_IPA="$(cd "$(dirname "$INPUT_IPA")" && pwd)/$(basename "$INPUT_IPA")"
mkdir -p "$(dirname "$OUTPUT_IPA")"
OUTPUT_IPA="$(cd "$(dirname "$OUTPUT_IPA")" && pwd)/$(basename "$OUTPUT_IPA")"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
unzip -q "$INPUT_IPA" -d "$WORK/ipa"
APP="$WORK/ipa/Payload/3105.app"
if [[ ! -d "$APP" ]]; then echo "App missing" >&2; exit 1; fi
xcrun actool --compile "$APP" \
    --platform iphoneos \
    --minimum-deployment-target 16.0 \
    --target-device iphone \
    --target-device ipad \
    --app-icon AppIcon \
    --output-partial-info-plist "$WORK/AssetCatalogInfo.plist" \
    "$HERE/../Assets.xcassets"
# The app's Info.plist needs the newly compiled icon catalog reference.
/usr/libexec/PlistBuddy -c 'Add :CFBundleIcons:CFBundlePrimaryIcon:CFBundleIconName string AppIcon' "$APP/Info.plist" 2>/dev/null || \
  /usr/libexec/PlistBuddy -c 'Set :CFBundleIcons:CFBundlePrimaryIcon:CFBundleIconName AppIcon' "$APP/Info.plist"
/usr/libexec/PlistBuddy -c 'Add :CFBundleIcons~ipad:CFBundlePrimaryIcon:CFBundleIconName string AppIcon' "$APP/Info.plist" 2>/dev/null || \
  /usr/libexec/PlistBuddy -c 'Set :CFBundleIcons~ipad:CFBundlePrimaryIcon:CFBundleIconName AppIcon' "$APP/Info.plist"
( cd "$WORK/ipa" && zip -qry "$OUTPUT_IPA" Payload )
unzip -tq "$OUTPUT_IPA" >/dev/null
echo "Asset catalog compiled. UNSIGNED IPA: $OUTPUT_IPA"
echo 'Sign with a valid certificate + provisioning profile for your device/distribution channel.'
